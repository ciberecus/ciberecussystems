
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { 
  Search, 
  Filter, 
  Briefcase, 
  ExternalLink, 
  Calendar,
  Clock,
  Star,
  Code,
  Smartphone,
  ShoppingCart,
  Users,
  BarChart3
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import type { Portfolio } from '@/lib/types'

interface PortfolioClientProps {
  projects: Portfolio[]
  categories: string[]
}

const categoryIcons: { [key: string]: any } = {
  'E-commerce': ShoppingCart,
  'Gestión': BarChart3,
  'Móvil': Smartphone,
  'Web': Code,
  'Empresarial': Users,
}

export default function PortfolioClient({ projects, categories }: PortfolioClientProps) {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  const filteredProjects = projects?.filter((project) => {
    const matchesSearch = project?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         project?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         project?.category?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         project?.technologies?.some(tech => tech?.toLowerCase()?.includes(searchTerm?.toLowerCase() || ''))
    const matchesCategory = selectedCategory === 'all' || project?.category === selectedCategory
    return matchesSearch && matchesCategory
  }) || []

  const featuredProjects = filteredProjects?.filter(project => project?.featured) || []
  const regularProjects = filteredProjects?.filter(project => !project?.featured) || []

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://cdn.abacus.ai/images/199254c2-959f-4b84-a09a-4e75e40203d6.png"
            alt="Portfolio Background"
            fill
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Briefcase className="text-primary animate-pulse-glow" size={48} />
              <h1 className="text-4xl md:text-6xl font-bold orbitron glow-text">
                Portafolio
              </h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Descubre los proyectos que hemos desarrollado con más de 10 años de experiencia. 
              Soluciones tecnológicas innovadoras para diversos sectores y necesidades.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 section-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Proyectos Completados', value: projects?.length || 0, icon: Briefcase },
              { label: 'Años de Experiencia', value: '10+', icon: Clock },
              { label: 'Tecnologías', value: '20+', icon: Code },
              { label: 'Clientes Satisfechos', value: '80+', icon: Star }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="card-cyberpunk">
                  <stat.icon className="mx-auto text-primary mb-2" size={24} />
                  <div className="text-2xl font-bold orbitron text-primary mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-muted/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col md:flex-row gap-4 items-center justify-between"
          >
            <div className="flex-1 max-w-md relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar proyectos, tecnologías..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-muted/20 border-border focus:border-primary"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48 bg-muted/20 border-border">
                    <SelectValue placeholder="Todas las categorías" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {categories?.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="text-sm text-muted-foreground">
                {filteredProjects?.length || 0} proyecto{(filteredProjects?.length || 0) !== 1 ? 's' : ''} encontrado{(filteredProjects?.length || 0) !== 1 ? 's' : ''}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Projects */}
      {featuredProjects?.length > 0 && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
            >
              Proyectos <span className="text-primary">Destacados</span>
            </motion.h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProjects?.map((project, index) => (
                <ProjectCard
                  key={project?.id}
                  project={project}
                  index={index}
                  featured
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Projects */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {regularProjects?.length > 0 && (
            <>
              <motion.h2
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
              >
                Otros <span className="text-secondary">Proyectos</span>
              </motion.h2>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {regularProjects?.map((project, index) => (
                  <ProjectCard
                    key={project?.id}
                    project={project}
                    index={index + (featuredProjects?.length || 0)}
                  />
                ))}
              </div>
            </>
          )}

          {filteredProjects?.length === 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="text-center py-12"
            >
              <Briefcase className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No se encontraron proyectos</h3>
              <p className="text-muted-foreground">
                Intenta ajustar tus filtros o términos de búsqueda
              </p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 section-gradient">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-bold orbitron">
              ¿Te gusta lo que{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                hacemos?
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Contactanos para conversar sobre tu próximo proyecto y cómo podemos ayudarte a alcanzar tus objetivos
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/#contact" className="btn-cyberpunk">
                Iniciar Proyecto
              </Link>
              <Link
                href="/herramientas"
                className="px-6 py-3 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-lg font-semibold transition-all duration-300"
              >
                Ver Servicios
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

interface ProjectCardProps {
  project: Portfolio
  index: number
  featured?: boolean
}

function ProjectCard({ project, index, featured = false }: ProjectCardProps) {
  const CategoryIcon = categoryIcons[project?.category || ''] || Briefcase

  const formatDate = (date: Date | string) => {
    if (!date) return 'N/A'
    return new Date(date).toLocaleDateString('es-ES', { 
      year: 'numeric', 
      month: 'short' 
    })
  }

  const calculateDuration = (startDate: Date | string, endDate?: Date | string | null) => {
    if (!startDate) return 'N/A'
    const start = new Date(startDate)
    const end = endDate ? new Date(endDate) : new Date()
    const months = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24 * 30))
    return `${months} mes${months !== 1 ? 'es' : ''}`
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      viewport={{ once: true }}
      className="group"
    >
      <div className={`card-cyberpunk hover-lift h-full ${featured ? 'ring-2 ring-primary/50' : ''}`}>
        {/* Project Image */}
        <div className="relative aspect-video mb-4 rounded-lg overflow-hidden">
          <Image
            src={project?.imageUrl || ''}
            alt={project?.title || ''}
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          
          {/* Category Badge */}
          <div className="absolute top-3 right-3 bg-background/80 backdrop-blur-sm text-foreground px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
            <CategoryIcon size={12} />
            <span>{project?.category}</span>
          </div>
          
          {/* Featured Badge */}
          {featured && (
            <div className="absolute top-3 left-3 bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
              <Star size={12} />
              <span>Destacado</span>
            </div>
          )}
          
          {/* Duration Badge */}
          <div className="absolute bottom-3 left-3 bg-primary/20 backdrop-blur-sm text-primary px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
            <Clock size={12} />
            <span>{calculateDuration(project?.startDate, project?.endDate)}</span>
          </div>
        </div>
        
        <div className="space-y-4 flex-1 flex flex-col">
          <div className="flex-1">
            <h3 className="text-lg font-bold group-hover:text-primary transition-colors mb-2 line-clamp-2">
              {project?.title}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed mb-3 line-clamp-3">
              {project?.description}
            </p>
            
            {/* Date Range */}
            <div className="flex items-center space-x-1 text-xs text-muted-foreground mb-3">
              <Calendar size={12} />
              <span>
                {formatDate(project?.startDate)} - {project?.endDate ? formatDate(project.endDate) : 'En curso'}
              </span>
            </div>
            
            {/* Technologies */}
            <div className="flex flex-wrap gap-1 mb-4">
              {project?.technologies?.slice(0, 3)?.map((tech, idx) => (
                <Badge key={idx} variant="secondary" className="text-xs">
                  {tech}
                </Badge>
              ))}
              {(project?.technologies?.length || 0) > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{(project?.technologies?.length || 0) - 3} más
                </Badge>
              )}
            </div>
          </div>
          
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center space-x-2">
              <CategoryIcon size={16} className="text-primary" />
              <span className="text-xs text-muted-foreground font-medium">
                {project?.category}
              </span>
            </div>
            
            <div className="flex space-x-2">
              {project?.projectUrl ? (
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                  className="hover:bg-primary hover:text-primary-foreground"
                >
                  <Link href={project.projectUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink size={14} />
                  </Link>
                </Button>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                  className="hover:bg-primary hover:text-primary-foreground"
                >
                  <Link href="/#contact">
                    Consultar
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
