
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { 
  Search, 
  Filter, 
  Wrench, 
  ExternalLink, 
  Code, 
  Smartphone, 
  Network, 
  Bot,
  GraduationCap,
  Shield,
  ShoppingCart,
  MessageCircle
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import type { Tool } from '@/lib/types'

interface ToolsClientProps {
  tools: Tool[]
  categories: string[]
}

const categoryIcons: { [key: string]: any } = {
  'Desarrollo Web': Code,
  'Desarrollo Móvil': Smartphone,
  'Inteligencia Artificial': Bot,
  'Networking': Network,
  'Comunicaciones': MessageCircle,
  'E-commerce': ShoppingCart,
  'Educación': GraduationCap,
  'Consultoría': Shield,
}

export default function ToolsClient({ tools, categories }: ToolsClientProps) {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  const filteredTools = tools?.filter((tool) => {
    const matchesSearch = tool?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         tool?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         tool?.category?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '')
    const matchesCategory = selectedCategory === 'all' || tool?.category === selectedCategory
    return matchesSearch && matchesCategory
  }) || []

  const featuredTools = filteredTools?.filter(tool => tool?.featured) || []
  const regularTools = filteredTools?.filter(tool => !tool?.featured) || []

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://cdn.abacus.ai/images/cf810987-245a-4e4b-9c45-f77d18f2032e.png"
            alt="Tools Background"
            fill
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Wrench className="text-primary animate-pulse-glow" size={48} />
              <h1 className="text-4xl md:text-6xl font-bold orbitron glow-text">
                Herramientas & Servicios
              </h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Soluciones tecnológicas avanzadas para impulsar tu negocio hacia el futuro digital. 
              Más de 10 años de experiencia en desarrollo y tecnologías de información.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-muted/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col md:flex-row gap-4 items-center justify-between"
          >
            <div className="flex-1 max-w-md relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar servicios, categorías..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-muted/20 border-border focus:border-primary"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48 bg-muted/20 border-border">
                    <SelectValue placeholder="Todas las categorías" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {categories?.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="text-sm text-muted-foreground">
                {filteredTools?.length || 0} servicio{(filteredTools?.length || 0) !== 1 ? 's' : ''} encontrado{(filteredTools?.length || 0) !== 1 ? 's' : ''}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Services */}
      {featuredTools?.length > 0 && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
            >
              Servicios <span className="text-primary">Destacados</span>
            </motion.h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredTools?.map((tool, index) => (
                <ServiceCard
                  key={tool?.id}
                  tool={tool}
                  index={index}
                  featured
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Services */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {regularTools?.length > 0 && (
            <>
              <motion.h2
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
              >
                Catálogo <span className="text-secondary">Completo</span>
              </motion.h2>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {regularTools?.map((tool, index) => (
                  <ServiceCard
                    key={tool?.id}
                    tool={tool}
                    index={index + (featuredTools?.length || 0)}
                  />
                ))}
              </div>
            </>
          )}

          {filteredTools?.length === 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="text-center py-12"
            >
              <Wrench className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No se encontraron servicios</h3>
              <p className="text-muted-foreground">
                Intenta ajustar tus filtros o términos de búsqueda
              </p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-20 section-gradient">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-bold orbitron">
              ¿Tienes un proyecto en{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                mente?
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Contactanos para conversar sobre cómo podemos ayudarte a materializar tu visión tecnológica
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/#contact" className="btn-cyberpunk">
                Solicitar Cotización
              </Link>
              <a
                href="https://wa.me/525541871969"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-lg font-semibold transition-all duration-300"
              >
                WhatsApp Directo
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

interface ServiceCardProps {
  tool: Tool
  index: number
  featured?: boolean
}

function ServiceCard({ tool, index, featured = false }: ServiceCardProps) {
  const CategoryIcon = categoryIcons[tool?.category || ''] || Wrench

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      viewport={{ once: true }}
      className="group"
    >
      <div className={`card-cyberpunk hover-lift h-full ${featured ? 'ring-2 ring-primary/50' : ''}`}>
        {/* Service Icon/Image */}
        <div className="relative aspect-video mb-4 rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
          {tool?.imageUrl ? (
            <Image
              src={tool.imageUrl}
              alt={tool?.name || ''}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-500"
            />
          ) : (
            <CategoryIcon size={48} className="text-primary group-hover:scale-110 transition-transform duration-300" />
          )}
          
          {/* Category Badge */}
          <div className="absolute top-3 right-3 bg-background/80 backdrop-blur-sm text-foreground px-2 py-1 rounded-full text-xs font-semibold">
            {tool?.category}
          </div>
          
          {/* Featured Badge */}
          {featured && (
            <div className="absolute top-3 left-3 bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-bold">
              Destacado
            </div>
          )}
        </div>
        
        <div className="space-y-4 flex-1 flex flex-col">
          <div className="flex-1">
            <h3 className="text-lg font-bold group-hover:text-primary transition-colors mb-2">
              {tool?.name}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {tool?.description}
            </p>
          </div>
          
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center space-x-2">
              <CategoryIcon size={16} className="text-primary" />
              <span className="text-xs text-muted-foreground font-medium">
                {tool?.category}
              </span>
            </div>
            
            <div className="flex space-x-2">
              {tool?.linkUrl ? (
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                  className="hover:bg-primary hover:text-primary-foreground"
                >
                  <Link href={tool.linkUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink size={14} />
                  </Link>
                </Button>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                  className="hover:bg-primary hover:text-primary-foreground"
                >
                  <Link href="/#contact">
                    Consultar
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
