
'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { Search, Filter, BookOpen, Star, DollarSign, User, Calendar, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import type { Book } from '@/lib/types'

interface LibraryClientProps {
  books: Book[]
  categories: string[]
}

export default function LibraryClient({ books, categories }: LibraryClientProps) {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedBook, setSelectedBook] = useState<Book | null>(null)

  const filteredBooks = books?.filter((book) => {
    const matchesSearch = book?.title?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         book?.author?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '') ||
                         book?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase() || '')
    const matchesCategory = selectedCategory === 'all' || book?.category === selectedCategory
    return matchesSearch && matchesCategory
  }) || []

  const featuredBooks = filteredBooks?.filter(book => book?.featured) || []
  const regularBooks = filteredBooks?.filter(book => !book?.featured) || []

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://cdn.abacus.ai/images/11dffe8a-0ff9-4af3-b5f5-38bcfe1b546c.png"
            alt="Library Background"
            fill
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-center space-x-3 mb-4">
              <BookOpen className="text-primary animate-pulse-glow" size={48} />
              <h1 className="text-4xl md:text-6xl font-bold orbitron glow-text">
                Librería Digital
              </h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Material didáctico con valor práctico para talleres y cursos presenciales. 
              Descubre libros especializados en tecnologías de información.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-muted/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col md:flex-row gap-4 items-center justify-between"
          >
            <div className="flex-1 max-w-md relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar libros, autores, categorías..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-muted/20 border-border focus:border-primary"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48 bg-muted/20 border-border">
                    <SelectValue placeholder="Todas las categorías" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    {categories?.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="text-sm text-muted-foreground">
                {filteredBooks?.length || 0} libro{(filteredBooks?.length || 0) !== 1 ? 's' : ''} encontrado{(filteredBooks?.length || 0) !== 1 ? 's' : ''}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Books */}
      {featuredBooks?.length > 0 && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
            >
              Libros <span className="text-primary">Destacados</span>
            </motion.h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredBooks?.map((book, index) => (
                <BookCard
                  key={book?.id}
                  book={book}
                  index={index}
                  onSelect={setSelectedBook}
                  featured
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Books */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {regularBooks?.length > 0 && (
            <>
              <motion.h2
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="text-2xl md:text-3xl font-bold orbitron mb-8 text-center"
              >
                Catálogo <span className="text-secondary">Completo</span>
              </motion.h2>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {regularBooks?.map((book, index) => (
                  <BookCard
                    key={book?.id}
                    book={book}
                    index={index + (featuredBooks?.length || 0)}
                    onSelect={setSelectedBook}
                  />
                ))}
              </div>
            </>
          )}

          {filteredBooks?.length === 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="text-center py-12"
            >
              <BookOpen className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No se encontraron libros</h3>
              <p className="text-muted-foreground">
                Intenta ajustar tus filtros o términos de búsqueda
              </p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Book Detail Modal */}
      <Dialog open={!!selectedBook} onOpenChange={() => setSelectedBook(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card border-border">
          {selectedBook && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl orbitron">
                  {selectedBook?.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="grid md:grid-cols-2 gap-8 mt-6">
                <div className="space-y-6">
                  <div className="relative aspect-[3/4] rounded-lg overflow-hidden">
                    <Image
                      src={selectedBook?.imageUrl || ''}
                      alt={selectedBook?.title || ''}
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{selectedBook?.title}</h3>
                    <div className="flex items-center space-x-4 text-muted-foreground mb-4">
                      <div className="flex items-center space-x-1">
                        <User size={16} />
                        <span>{selectedBook?.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar size={16} />
                        <span>{selectedBook?.createdAt ? new Date(selectedBook.createdAt).getFullYear() : 'N/A'}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 mb-6">
                      <div className="flex items-center space-x-1">
                        <DollarSign className="text-primary" size={20} />
                        <span className="text-2xl font-bold text-primary">
                          ${selectedBook?.price?.toFixed(2)} {selectedBook?.currency}
                        </span>
                      </div>
                      <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm font-semibold">
                        {selectedBook?.category}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-1 mb-6">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={16} className="text-yellow-400 fill-current" />
                      ))}
                      <span className="ml-2 text-muted-foreground">(5.0)</span>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-lg font-semibold mb-3">Descripción</h4>
                    <p className="text-muted-foreground leading-relaxed">
                      {selectedBook?.description}
                    </p>
                  </div>
                  
                  <div className="pt-6 border-t border-border">
                    <div className="flex space-x-4">
                      <button className="btn-cyberpunk flex-1">
                        Contactar para Comprar
                      </button>
                      <button className="px-6 py-3 border border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-lg transition-colors">
                        Más Info
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface BookCardProps {
  book: Book
  index: number
  onSelect: (book: Book) => void
  featured?: boolean
}

function BookCard({ book, index, onSelect, featured = false }: BookCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      viewport={{ once: true }}
      className="group cursor-pointer"
      onClick={() => onSelect(book)}
    >
      <div className={`card-cyberpunk hover-lift h-full ${featured ? 'ring-2 ring-primary/50' : ''}`}>
        <div className="relative aspect-[3/4] mb-4 rounded-lg overflow-hidden">
          <Image
            src={book?.imageUrl || ''}
            alt={book?.title || ''}
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
          
          {/* Price Badge */}
          <div className="absolute top-3 right-3 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-2 py-1 rounded-full text-sm font-bold flex items-center space-x-1">
            <DollarSign size={12} />
            <span>{book?.price?.toFixed(2)}</span>
          </div>
          
          {/* Featured Badge */}
          {featured && (
            <div className="absolute top-3 left-3 bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
              <Star size={12} />
              <span>Destacado</span>
            </div>
          )}
          
          {/* Category */}
          <div className="absolute bottom-3 left-3 bg-background/80 backdrop-blur-sm text-foreground px-2 py-1 rounded-full text-xs font-semibold">
            {book?.category}
          </div>
        </div>
        
        <div className="space-y-2">
          <h3 className="font-bold group-hover:text-primary transition-colors line-clamp-2">
            {book?.title}
          </h3>
          <p className="text-sm text-muted-foreground">
            {book?.author}
          </p>
          <p className="text-muted-foreground text-sm leading-relaxed line-clamp-2">
            {book?.description}
          </p>
        </div>
      </div>
    </motion.div>
  )
}
