
'use client'

import { motion } from 'framer-motion'
import { Session } from 'next-auth'
import Link from 'next/link'
import { signOut } from 'next-auth/react'
import { 
  BookOpen, 
  Wrench, 
  Briefcase, 
  MessageCircle, 
  Users,
  BarChart3,
  LogOut,
  Plus,
  Eye
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Book, Tool, Portfolio, Contact } from '@/lib/types'

interface AdminDashboardProps {
  session: Session
  stats: {
    totalBooks: number
    totalTools: number
    totalProjects: number
    newContacts: number
  }
  recentBooks: Book[]
  recentTools: Tool[]
  recentProjects: Portfolio[]
  newContacts: Contact[]
}

export default function AdminDashboard({ 
  session, 
  stats, 
  recentBooks, 
  recentTools, 
  recentProjects, 
  newContacts 
}: AdminDashboardProps) {
  return (
    <div className="min-h-screen pt-16 bg-gradient-to-br from-background to-muted/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between mb-8"
        >
          <div>
            <h1 className="text-3xl font-bold orbitron glow-text">
              Panel de Administración
            </h1>
            <p className="text-muted-foreground mt-2">
              Bienvenido, {session?.user?.email}
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/" className="btn-cyberpunk">
              <Eye size={16} className="mr-2" />
              Ver Sitio
            </Link>
            <Button
              variant="outline"
              onClick={() => signOut({ callbackUrl: '/admin/login' })}
              className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
            >
              <LogOut size={16} className="mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { 
              title: 'Libros', 
              value: stats.totalBooks, 
              icon: BookOpen, 
              color: 'text-blue-400',
              bg: 'bg-blue-400/10',
              href: '/admin/books'
            },
            { 
              title: 'Herramientas', 
              value: stats.totalTools, 
              icon: Wrench, 
              color: 'text-green-400',
              bg: 'bg-green-400/10',
              href: '/admin/tools'
            },
            { 
              title: 'Proyectos', 
              value: stats.totalProjects, 
              icon: Briefcase, 
              color: 'text-purple-400',
              bg: 'bg-purple-400/10',
              href: '/admin/portfolio'
            },
            { 
              title: 'Mensajes Nuevos', 
              value: stats.newContacts, 
              icon: MessageCircle, 
              color: 'text-yellow-400',
              bg: 'bg-yellow-400/10',
              href: '/admin/contacts'
            }
          ].map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Link href={stat.href} className="block">
                <div className="card-cyberpunk hover-lift group">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.title}</p>
                      <p className="text-3xl font-bold orbitron group-hover:text-primary transition-colors">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`p-4 rounded-full ${stat.bg}`}>
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="mb-8"
        >
          <h2 className="text-xl font-bold orbitron mb-4">Acciones Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { 
                title: 'Nuevo Libro', 
                description: 'Agregar libro a la librería',
                icon: BookOpen,
                href: '/admin/books/new',
                color: 'text-blue-400'
              },
              { 
                title: 'Nueva Herramienta', 
                description: 'Agregar servicio/herramienta',
                icon: Wrench,
                href: '/admin/tools/new',
                color: 'text-green-400'
              },
              { 
                title: 'Nuevo Proyecto', 
                description: 'Agregar al portafolio',
                icon: Briefcase,
                href: '/admin/portfolio/new',
                color: 'text-purple-400'
              }
            ].map((action, index) => (
              <Link key={action.title} href={action.href}>
                <div className="card-cyberpunk hover-lift group h-full">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 rounded-lg bg-muted/20 group-hover:bg-muted/40 transition-colors">
                      <action.icon className={`h-6 w-6 ${action.color}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold group-hover:text-primary transition-colors">
                        {action.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {action.description}
                      </p>
                    </div>
                    <Plus className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </motion.div>

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Books */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="card-cyberpunk"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center">
                <BookOpen className="mr-2 h-5 w-5 text-blue-400" />
                Libros Recientes
              </h3>
              <Link href="/admin/books" className="text-sm text-primary hover:underline">
                Ver todos
              </Link>
            </div>
            
            <div className="space-y-3">
              {recentBooks?.length ? (
                recentBooks.map((book) => (
                  <div key={book?.id} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{book?.title}</p>
                      <p className="text-xs text-muted-foreground">{book?.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-primary">
                        ${book?.price?.toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-4">No hay libros aún</p>
              )}
            </div>
          </motion.div>

          {/* Recent Messages */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="card-cyberpunk"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center">
                <MessageCircle className="mr-2 h-5 w-5 text-yellow-400" />
                Mensajes Nuevos
              </h3>
              <Link href="/admin/contacts" className="text-sm text-primary hover:underline">
                Ver todos
              </Link>
            </div>
            
            <div className="space-y-3">
              {newContacts?.length ? (
                newContacts.map((contact) => (
                  <div key={contact?.id} className="p-3 bg-muted/20 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium text-sm">{contact?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {contact?.createdAt ? new Date(contact.createdAt).toLocaleDateString() : 'N/A'}
                      </p>
                    </div>
                    <p className="text-xs text-muted-foreground mb-1">{contact?.email}</p>
                    <p className="text-sm">{contact?.subject}</p>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-4">No hay mensajes nuevos</p>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
