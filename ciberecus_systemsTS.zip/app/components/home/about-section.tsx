
'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import { Shield, Target, Zap, Heart } from 'lucide-react'

const values = [
  {
    icon: Target,
    title: 'Precisión',
    description: 'Código limpio y soluciones exactas para cada proyecto'
  },
  {
    icon: Zap,
    title: 'Rapidez',
    description: 'Desarrollo ágil sin comprometer la calidad'
  },
  {
    icon: Shield,
    title: 'Confiabilidad',
    description: 'Más de 10 años de experiencia respaldándonos'
  },
  {
    icon: Heart,
    title: 'Compromiso',
    description: 'Trabajamos para apoyarte en tus necesidades de información'
  }
]

export default function AboutSection() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0">
        <Image
          src="https://cdn.abacus.ai/images/199254c2-959f-4b84-a09a-4e75e40203d6.png"
          alt="Tech Background"
          fill
          className="object-cover opacity-5"
        />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-bold orbitron">
              Construyendo el{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                Futuro Digital
              </span>
            </h2>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              En <strong className="text-primary">Ciberecus Systems</strong> combinamos más de una década 
              de experiencia en desarrollo web, aplicaciones móviles y tecnologías emergentes. 
              Especializados en crear soluciones robustas con <strong>PHP</strong>, desarrollamos 
              desde módulos simples hasta aplicaciones empresariales complejas.
            </p>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              Nuestro enfoque integral incluye desarrollo web responsivo, aplicaciones móviles 
              multiplataforma, implementación de redes, servicios VoIP y ahora, 
              <strong className="text-secondary"> Agentes IA para proyectos empresariales</strong>.
            </p>
            
            <div className="pt-4">
              <div className="grid grid-cols-2 gap-4">
                {values.map((value, index) => (
                  <motion.div
                    key={value.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    viewport={{ once: true }}
                    className="flex items-center space-x-3 p-3 rounded-lg bg-muted/20 hover:bg-muted/40 transition-colors"
                  >
                    <div className="p-2 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20">
                      <value.icon size={20} className="text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm">{value.title}</h3>
                      <p className="text-xs text-muted-foreground">{value.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Visual Elements */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative aspect-square max-w-md mx-auto">
              <Image
                src="https://cdn.abacus.ai/images/cf810987-245a-4e4b-9c45-f77d18f2032e.png"
                alt="Ciberecus Technology"
                fill
                className="object-cover rounded-2xl neon-glow"
              />
              
              {/* Floating elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -left-4 w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center neon-glow"
              >
                <span className="text-sm font-bold orbitron">10+</span>
              </motion.div>
              
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute -bottom-4 -right-4 w-20 h-20 bg-gradient-to-br from-secondary to-accent rounded-full flex items-center justify-center neon-glow"
              >
                <span className="text-xs font-bold orbitron text-center">AÑOS<br/>EXP</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
