
'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Code, Smartphone, Network, Bot } from 'lucide-react'

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://cdn.abacus.ai/images/35dd93a8-69c0-4d39-b707-85ea334a27a4.png"
          alt="Cyberpunk Tech Background"
          fill
          className="object-cover opacity-30"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background" />
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 grid-pattern opacity-20" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          {/* Logo */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="flex justify-center mb-8"
          >
            <div className="relative w-32 h-32 animate-pulse-glow">
              <Image
                src="https://cdn.abacus.ai/images/e1a2cfc7-0871-42a2-9fe6-c007af52ca3b.png"
                alt="Ciberecus Systems Logo"
                fill
                className="object-contain"
              />
            </div>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="text-5xl md:text-7xl font-bold orbitron glow-text mb-6"
          >
            CIBERECUS
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              SYSTEMS
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed"
          >
            Desarrollo web y tecnologías de información con más de{' '}
            <span className="text-primary font-semibold">10 años</span> de experiencia. 
            Soluciones tecnológicas avanzadas para el futuro digital.
          </motion.p>

          {/* Service Icons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.6 }}
            className="flex justify-center space-x-8 my-12"
          >
            {[
              { icon: Code, label: 'Web Dev', color: 'text-blue-400' },
              { icon: Smartphone, label: 'Mobile', color: 'text-green-400' },
              { icon: Network, label: 'Networks', color: 'text-purple-400' },
              { icon: Bot, label: 'AI Agents', color: 'text-pink-400' }
            ].map((service, index) => (
              <motion.div
                key={service.label}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 1 + index * 0.1, duration: 0.5 }}
                className="flex flex-col items-center space-y-2 group"
              >
                <div className={`p-4 rounded-full bg-muted/20 group-hover:bg-muted/40 transition-all duration-300 ${service.color}`}>
                  <service.icon size={32} className="animate-float" style={{ animationDelay: `${index * 0.5}s` }} />
                </div>
                <span className="text-sm font-medium">{service.label}</span>
              </motion.div>
            ))}
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Link href="/herramientas" className="btn-cyberpunk group">
              Ver Servicios
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/libreria"
              className="px-6 py-3 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-lg font-semibold transition-all duration-300 hover:scale-105"
            >
              Explorar Librería
            </Link>
            <Link
              href="/portafolio"
              className="px-6 py-3 text-muted-foreground hover:text-primary border-2 border-muted hover:border-primary rounded-lg font-semibold transition-all duration-300"
            >
              Ver Portafolio
            </Link>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 0.6 }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          >
            <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
              <motion.div
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-1 h-3 bg-primary rounded-full mt-2"
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
