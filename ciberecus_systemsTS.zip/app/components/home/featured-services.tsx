
'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, ExternalLink } from 'lucide-react'

const featuredServices = [
  {
    id: 1,
    title: 'Desarrollo Web a la Medida',
    description: 'Creación de páginas y portales web para ofrecer servicios y/o productos. Diseños modernos, código limpio y completamente responsive.',
    image: 'https://cdn.abacus.ai/images/1b9c5bcd-0519-430d-850a-5147e479bf0b.png',
    category: 'Desarrollo Web',
    featured: true
  },
  {
    id: 2,
    title: 'Aplicaciones Móviles',
    description: 'Desarrollo de aplicaciones para Android & iOS. Soluciones móviles integrando servicios web con paquetes integrados disponibles.',
    image: 'https://cdn.abacus.ai/images/1b9c5bcd-0519-430d-850a-5147e479bf0b.png',
    category: 'Desarrollo Móvil',
    featured: true
  },
  {
    id: 3,
    title: 'Agentes IA para Proyectos Empresariales',
    description: 'Automatización de tareas y procesos, soporte inteligente de decisiones, chatbots, orquestación de flujos de trabajo y análisis de datos con IA.',
    image: 'https://cdn.abacus.ai/images/1b9c5bcd-0519-430d-850a-5147e479bf0b.png',
    category: 'Inteligencia Artificial',
    featured: true
  }
]

export default function FeaturedServices() {
  return (
    <section className="py-20 section-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold orbitron mb-4">
            Servicios{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              Destacados
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Soluciones tecnológicas avanzadas para impulsar tu negocio hacia el futuro digital
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="card-cyberpunk hover-lift h-full">
                <div className="relative aspect-video mb-4 rounded-lg overflow-hidden">
                  <Image
                    src={service.image}
                    alt={service.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1 text-xs font-semibold bg-primary text-primary-foreground rounded-full">
                      {service.category}
                    </span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-xl font-bold group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {service.description}
                  </p>
                  
                  <div className="pt-4">
                    <Link 
                      href="/herramientas"
                      className="inline-flex items-center space-x-2 text-primary hover:text-secondary transition-colors font-semibold"
                    >
                      <span>Conoce más</span>
                      <ExternalLink size={16} />
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Link href="/herramientas" className="btn-cyberpunk group">
            Ver Todos los Servicios
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
