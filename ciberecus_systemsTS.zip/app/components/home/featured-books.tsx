
'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { BookOpen, ArrowRight, Star, DollarSign } from 'lucide-react'

const featuredBooks = [
  {
    id: 1,
    title: 'Algoritmia Computacional',
    author: 'José Luis Pérez Resendiz',
    price: 210.00,
    description: 'Ideal para los iniciados en la programación de propósito general. Fundamentos de algoritmos y lógica de programación.',
    image: 'https://cdn.abacus.ai/images/cf00db39-117a-4765-a973-1775f386a9e3.png',
    category: 'Programación',
    featured: true
  },
  {
    id: 2,
    title: 'Desarrollo de Aplicaciones Móviles con Flutter',
    author: 'José Luis Pérez Resendiz',
    price: 620.00,
    description: 'Lo que necesitas saber para crear tus propias aplicaciones móviles multiplataforma.',
    image: 'https://cdn.abacus.ai/images/3b6ae7af-557a-46c3-a436-71ac68b365c1.png',
    category: 'Desarrollo Móvil',
    featured: true
  },
  {
    id: 3,
    title: 'Creación de Portales Web',
    author: 'José Luis Pérez Resendiz',
    price: 434.66,
    description: 'Todas las bases y prácticas mínimas básicas para la formación FullStack (FrontEnd+BackEnd).',
    image: 'https://cdn.abacus.ai/images/3d8fe3fa-c06c-46d3-ad93-da90ae264765.png',
    category: 'Desarrollo Web',
    featured: true
  }
]

export default function FeaturedBooks() {
  return (
    <section className="py-20 relative">
      <div className="absolute inset-0">
        <Image
          src="https://cdn.abacus.ai/images/11dffe8a-0ff9-4af3-b5f5-38bcfe1b546c.png"
          alt="Library Background"
          fill
          className="object-cover opacity-5"
        />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center space-x-3 mb-4">
            <BookOpen className="text-primary" size={32} />
            <h2 className="text-3xl md:text-4xl font-bold orbitron">
              Librería{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                Digital
              </span>
            </h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Material didáctico con valor práctico para talleres y cursos presenciales
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredBooks.map((book, index) => (
            <motion.div
              key={book.id}
              initial={{ opacity: 0, y: 50, rotateY: -15 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
              className="group perspective-1000"
            >
              <div className="card-cyberpunk hover-lift h-full transform-gpu transition-all duration-300 group-hover:scale-105">
                <div className="relative aspect-[3/4] mb-4 rounded-lg overflow-hidden">
                  <Image
                    src={book.image}
                    alt={book.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent" />
                  
                  {/* Price Badge */}
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-3 py-1 rounded-full text-sm font-bold flex items-center space-x-1">
                    <DollarSign size={14} />
                    <span>{book.price.toFixed(2)}</span>
                  </div>
                  
                  {/* Category */}
                  <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-sm text-foreground px-3 py-1 rounded-full text-xs font-semibold">
                    {book.category}
                  </div>
                  
                  {/* Rating Stars */}
                  <div className="absolute bottom-4 left-4 flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={14} className="text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h3 className="text-lg font-bold group-hover:text-primary transition-colors line-clamp-2">
                    {book.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    por <span className="text-primary font-medium">{book.author}</span>
                  </p>
                  <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3">
                    {book.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Link href="/libreria" className="btn-cyberpunk group">
            Explorar Librería Completa
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
