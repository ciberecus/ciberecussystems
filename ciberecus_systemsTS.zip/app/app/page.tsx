
import HeroSection from '@/components/home/hero-section'
import FeaturedServices from '@/components/home/featured-services'
import AboutSection from '@/components/home/about-section'
import ContactSection from '@/components/home/contact-section'
import FeaturedBooks from '@/components/home/featured-books'
import StatsSection from '@/components/home/stats-section'

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <StatsSection />
      <AboutSection />
      <FeaturedServices />
      <FeaturedBooks />
      <ContactSection />
    </div>
  )
}
