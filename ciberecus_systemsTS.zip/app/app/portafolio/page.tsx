
import { prisma } from '@/lib/db'
import PortfolioClient from '@/components/portafolio/portfolio-client'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Portafolio de Proyectos | Ciberecus Systems',
  description: 'Descubre los proyectos que hemos desarrollado: aplicaciones web, móviles, sistemas empresariales y soluciones tecnológicas innovadoras.',
}

export default async function PortafolioPage() {
  const projects = await prisma.portfolio.findMany({
    where: { status: 'active' },
    orderBy: [
      { featured: 'desc' },
      { startDate: 'desc' }
    ]
  })

  const categories = await prisma.portfolio.groupBy({
    by: ['category'],
    where: { status: 'active' }
  })

  return (
    <PortfolioClient 
      projects={projects}
      categories={categories.map(c => c.category)}
    />
  )
}
