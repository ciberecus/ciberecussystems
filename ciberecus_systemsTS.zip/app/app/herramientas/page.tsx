
import { prisma } from '@/lib/db'
import ToolsClient from '@/components/herramientas/tools-client'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Herramientas y Servicios | Ciberecus Systems',
  description: 'Descubre nuestros servicios de desarrollo web, aplicaciones móviles, redes, capacitación en TI y agentes IA para proyectos empresariales.',
}

export default async function HerramientasPage() {
  const tools = await prisma.tool.findMany({
    where: { status: 'active' },
    orderBy: [
      { featured: 'desc' },
      { createdAt: 'desc' }
    ]
  })

  const categories = await prisma.tool.groupBy({
    by: ['category'],
    where: { status: 'active' }
  })

  return (
    <ToolsClient 
      tools={tools}
      categories={categories.map(c => c.category)}
    />
  )
}
