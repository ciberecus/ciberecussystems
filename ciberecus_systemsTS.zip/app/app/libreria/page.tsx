
import { prisma } from '@/lib/db'
import LibraryClient from '@/components/libreria/library-client'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Librería Digital | Ciberecus Systems',
  description: 'Explora nuestra colección de libros de programación y tecnologías de información. Material didáctico con valor práctico.',
}

export default async function LibreriaPage() {
  const books = await prisma.book.findMany({
    where: { status: 'available' },
    orderBy: [
      { featured: 'desc' },
      { createdAt: 'desc' }
    ]
  })

  const categories = await prisma.book.groupBy({
    by: ['category'],
    where: { status: 'available' }
  })

  return (
    <LibraryClient 
      books={books}
      categories={categories.map(c => c.category)}
    />
  )
}
